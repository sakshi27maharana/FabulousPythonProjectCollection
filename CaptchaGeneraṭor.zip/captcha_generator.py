# captcha module
from captcha.image import ImageCaptcha as ic

#image instance
image = ic(width = 280, height = 90)

#image captcha
captcha_text = "github27"

#captcha generator
data = image.generate(captcha_text)

#write in image
image.write(captcha_text, 'captcha.png')