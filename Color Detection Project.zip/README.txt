AIM::::::::

A python programming to detect various colors using webcam.



## Disclaimer :

This code is saved from the my explore city to the different projects be a part of my github store.