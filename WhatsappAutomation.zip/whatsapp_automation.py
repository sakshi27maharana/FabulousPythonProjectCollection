import  pywhatkit as whatsaapp

whatsaapp.sendwhatmsg("+0999999999", "Hi, This is Sakshi. Nice to meet you!", 0, 0)